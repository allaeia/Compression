TP de Compression
================

Auteurs :
---------
Gu�non Marie & Favreau Jean-Dominique

Date :
------
30/01/2014

Librairies :
------------
Les librairies n�cessaires � ce projet sont :<br>

* OpenCV

<br>Merci de v�rifier que ces librairies sont bien install�es sur votre ordinateur avant d'essayer de compiler notre projet.

Compilation :
-------------
Pour compiler notre projet, il suffit de faire tourner la commande `qmake ..;make` dans le dossier `./code/build`
<br>
<b>Attention</b>: il faut donc avoir les modules `qmake` correspondants aux librairies pr�cis�es ci-dessus!

Execution :
-----------

* il suffit de lancer la commande `./compression` dans le dossier `./code/build`

